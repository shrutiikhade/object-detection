# object detection > 2024-06-18 8:17am
https://universe.roboflow.com/shruti-khade/object-detection-bewc1

Provided by a Roboflow user
License: CC BY 4.0

